// ============================================================
// RENDERER.JS  –  The brain of your desktop cat 🐱
// ============================================================
const { ipcRenderer } = require('electron');

// ── HTML elements ────────────────────────────────────────────
const catSprite   = document.getElementById('cat-sprite');
const speechBub   = document.getElementById('speech-bubble');
const speechText  = document.getElementById('speech-text');
const actionPopup = document.getElementById('action-popup');
const hungerFill  = document.getElementById('hunger-fill');
const hungerPct   = document.getElementById('hunger-pct');
const btnFeed     = document.getElementById('btn-feed');
const btnSleep    = document.getElementById('btn-sleep');
const btnChat     = document.getElementById('btn-chat');
const chatBox     = document.getElementById('chat-box');
const chatInput   = document.getElementById('chat-input');
const chatSend    = document.getElementById('chat-send');
const closeBtn    = document.getElementById('close-btn');

// SVG elements we'll modify
const irisL       = document.getElementById('iris-l');
const irisR       = document.getElementById('iris-r');
const pupilL      = document.getElementById('pupil-l');
const pupilR      = document.getElementById('pupil-r');
const closedEyes  = document.getElementById('closed-eyes');

// ── Cat state ────────────────────────────────────────────────
const cat = {
  state: 'idle',        // idle | walking | sleeping | eating | annoyed | happy
  hunger: 0,            // 0 (full) → 100 (starving)
  lastInteract: Date.now(),
  popupOpen: false,
  chatOpen: false,
  blinkTimer: null,
};

// ── Audio context (created on first interaction) ─────────────
let audioCtx = null;
function getAudio() {
  if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  return audioCtx;
}

// ============================================================
// 🔊  SOUNDS
// ============================================================
function playSound(type) {
  try {
    const ctx = getAudio();
    const t = ctx.currentTime;

    if (type === 'speak') {
      chirp(ctx, 520, 820, t, 0.22, 0.22);

    } else if (type === 'purr') {
      // Gentle purring rumble
      const osc = ctx.createOscillator();
      const g   = ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.type = 'sawtooth';
      osc.frequency.value = 28;
      g.gain.setValueAtTime(0.18, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 1.2);
      osc.start(t); osc.stop(t + 1.2);

    } else if (type === 'eat') {
      chirp(ctx, 380, 500, t,       0.25, 0.18);
      chirp(ctx, 420, 560, t + 0.18, 0.25, 0.18);
      chirp(ctx, 460, 600, t + 0.36, 0.25, 0.18);

    } else if (type === 'pee') {
      const osc = ctx.createOscillator();
      const g   = ctx.createGain();
      osc.connect(g); g.connect(ctx.destination);
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(300, t);
      osc.frequency.exponentialRampToValueAtTime(80, t + 0.5);
      g.gain.setValueAtTime(0.2, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.5);
      osc.start(t); osc.stop(t + 0.5);

    } else if (type === 'scream') {
      // 😱 VERY LOUD obnoxious cat scream using multiple oscillators
      const freqs = [900, 1350, 1800, 2400];
      freqs.forEach((f, i) => {
        const osc  = ctx.createOscillator();
        const gain = ctx.createGain();
        const lfo  = ctx.createOscillator();   // for vibrato
        const lfog = ctx.createGain();
        lfo.connect(lfog); lfog.connect(osc.frequency);
        osc.connect(gain); gain.connect(ctx.destination);

        osc.type = i % 2 === 0 ? 'sawtooth' : 'square';
        lfo.type = 'sine';
        lfo.frequency.value = 9 + i * 2.5;
        lfog.gain.value = 140;

        osc.frequency.setValueAtTime(f, t);
        osc.frequency.exponentialRampToValueAtTime(f * 1.4, t + 0.6);
        osc.frequency.exponentialRampToValueAtTime(f * 0.75, t + 1.2);
        osc.frequency.exponentialRampToValueAtTime(f * 1.2, t + 1.8);

        gain.gain.setValueAtTime(0.28, t);   // 0.28 × 4 = very loud
        gain.gain.setValueAtTime(0.28, t + 1.9);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 2.2);

        lfo.start(t); osc.start(t);
        lfo.stop(t + 2.2); osc.stop(t + 2.2);
      });
    }
  } catch (e) { /* audio failed quietly */ }
}

function chirp(ctx, f1, f2, startTime, volume, dur) {
  const osc = ctx.createOscillator();
  const g   = ctx.createGain();
  osc.connect(g); g.connect(ctx.destination);
  osc.type = 'sine';
  osc.frequency.setValueAtTime(f1, startTime);
  osc.frequency.exponentialRampToValueAtTime(f2, startTime + dur);
  g.gain.setValueAtTime(volume, startTime);
  g.gain.exponentialRampToValueAtTime(0.001, startTime + dur);
  osc.start(startTime); osc.stop(startTime + dur);
}

// ============================================================
// 💬  SPEECH BUBBLE
// ============================================================
let speechTimer = null;
function say(msg, ms = 3500) {
  speechText.textContent = msg;
  speechBub.classList.add('visible');
  playSound('speak');
  clearTimeout(speechTimer);
  speechTimer = setTimeout(() => speechBub.classList.remove('visible'), ms);
}

// ============================================================
// 🎭  CAT STATE MACHINE
// Sets the CSS class on #cat-sprite and updates SVG elements
// ============================================================
function setState(newState) {
  const prev = cat.state;
  cat.state = newState;

  // Remove all state classes
  catSprite.classList.remove(
    'idle','walking','sleeping','eating','annoyed','happy'
  );

  // Add new state class
  catSprite.classList.add(newState);

  // Show/hide SVG overlays
  document.getElementById('sleep-zzz').style.opacity  = newState === 'sleeping' ? '1' : '0';
  document.getElementById('food-bowl').style.opacity  = newState === 'eating'   ? '1' : '0';
  document.getElementById('hearts').style.opacity     = newState === 'happy'    ? '1' : '0';
  document.getElementById('angry-brows').style.opacity= newState === 'annoyed'  ? '1' : '0';
  document.getElementById('walk-legs').style.opacity  = newState === 'walking'  ? '1' : '0';

  if (newState === 'sleeping') {
    // Hide open eyes, show closed
    irisL.setAttribute('opacity','0'); irisR.setAttribute('opacity','0');
    pupilL.setAttribute('opacity','0'); pupilR.setAttribute('opacity','0');
    closedEyes.setAttribute('opacity','1');
    stopBlinking();
  } else {
    irisL.setAttribute('opacity','1'); irisR.setAttribute('opacity','1');
    pupilL.setAttribute('opacity','1'); pupilR.setAttribute('opacity','1');
    closedEyes.setAttribute('opacity','0');
    if (prev === 'sleeping') startBlinking(); // resume blinking on wake
  }
}

// ============================================================
// 😉  BLINKING
// ============================================================
function blink() {
  if (cat.state === 'sleeping') return;
  closedEyes.setAttribute('opacity','1');
  irisL.setAttribute('opacity','0'); irisR.setAttribute('opacity','0');
  pupilL.setAttribute('opacity','0'); pupilR.setAttribute('opacity','0');
  setTimeout(() => {
    closedEyes.setAttribute('opacity','0');
    irisL.setAttribute('opacity','1'); irisR.setAttribute('opacity','1');
    pupilL.setAttribute('opacity','1'); pupilR.setAttribute('opacity','1');
  }, 130);
}
function startBlinking() {
  stopBlinking();
  function scheduleBlink() {
    cat.blinkTimer = setTimeout(() => {
      blink();
      scheduleBlink();
    }, 3000 + Math.random() * 5000);
  }
  scheduleBlink();
}
function stopBlinking() {
  clearTimeout(cat.blinkTimer);
}
startBlinking();

// ============================================================
// 🐾  CAT WALKING — moves the Electron window to a new spot
// ============================================================
async function walkTo(targetX, targetY) {
  setState('walking');

  const startPos = await ipcRenderer.invoke('get-window-pos');
  const dx = targetX - startPos[0];

  // Face the correct direction
  catSprite.classList.toggle('facing-left', dx < 0);

  const STEPS = 40;
  let step = 0;

  await new Promise(resolve => {
    const iv = setInterval(() => {
      step++;
      const t = step / STEPS;
      const e = t < 0.5 ? 2*t*t : -1 + (4 - 2*t)*t; // ease-in-out

      ipcRenderer.send('move-window',
        Math.round(startPos[0] + dx * e),
        Math.round(startPos[1] + (targetY - startPos[1]) * e)
      );

      if (step >= STEPS) { clearInterval(iv); resolve(); }
    }, 22);
  });

  catSprite.classList.remove('facing-left');
  setState('idle');
}

// Pick a random spot in the lower-right zone and walk there
async function wander() {
  if (cat.state !== 'idle') return;
  const screen = await ipcRenderer.invoke('get-screen-size');

  // Lower-right quadrant: right 50%, lower 40% of screen
  const minX = Math.floor(screen.width * 0.42);
  const maxX = screen.width - 285;
  const minY = Math.floor(screen.height * 0.50);
  const maxY = screen.height - 315;

  const tx = minX + Math.floor(Math.random() * (maxX - minX));
  const ty = minY + Math.floor(Math.random() * (maxY - minY));

  await walkTo(tx, ty);
}

// ============================================================
// 😴  SLEEP  &  WAKE
// ============================================================
function goSleep() {
  setState('sleeping');
  closePopup();
  say("mrrp... zz... I dream of fish... 🐟💤", 5000);

  const napMs = 12000 + Math.random() * 10000;
  setTimeout(wakeUp, napMs);
}

function wakeUp() {
  if (cat.state !== 'sleeping') return;
  setState('idle');
  const lines = [
    "WAKEY WAKEY 😤 I am back and confused",
    "Oh! You're still here. I wasn't lonely. Not even a little.",
    "I slept and dreamed I was a fancy soup. Make of that what you will.",
    "I have returned. Refresh the feed.",
  ];
  say(pick(lines), 3200);
}

// ============================================================
// 🍕  HUNGER
// ============================================================
function tickHunger() {
  if (cat.state === 'sleeping') return;
  cat.hunger = Math.min(100, cat.hunger + 1);
  updateHungerBar();

  if (cat.hunger === 45) say("hmm my tummy is making opinions... 🤔");
  if (cat.hunger === 68) say("FOOD. I need FOOD. This is a situation. 🍕");
  if (cat.hunger === 85) say("I AM LITERALLY FADING AWAY 💀 goodbye world");
  if (cat.hunger >= 100) {
    cat.hunger = 100;
    say("FINE. I WILL JUDGE YOU IN SILENCE. 😤😤😤");
  }
}

function updateHungerBar() {
  hungerFill.style.width = cat.hunger + '%';
  hungerPct.textContent  = cat.hunger + '%';

  if (cat.hunger < 40)
    hungerFill.style.background = 'linear-gradient(90deg,#4ade80,#22c55e)';
  else if (cat.hunger < 72)
    hungerFill.style.background = 'linear-gradient(90deg,#fbbf24,#f59e0b)';
  else
    hungerFill.style.background = 'linear-gradient(90deg,#f87171,#ef4444)';
}

function feedCat() {
  cat.hunger = Math.max(0, cat.hunger - 50);
  cat.lastInteract = Date.now();
  updateHungerBar();

  setState('eating');
  document.getElementById('food-bowl').style.opacity = '1';
  playSound('eat');

  const lines = [
    "NOM NOM NOM 😋 10/10 would eat again",
    "DELICIOUS! What was it? Don't tell me. Give me more.",
    "I ate it before I could even taste it. Feed me again.",
    "Outstanding. Spectacular. Still hungry though.",
    "THANK YOU!! ...I need more now please.",
  ];
  say(pick(lines), 3000);

  setTimeout(() => {
    setState('idle');
    document.getElementById('food-bowl').style.opacity = '0';
  }, 2800);
}

// ============================================================
// 🤚  PETTING
// ============================================================
function petTheCat() {
  cat.lastInteract = Date.now();
  if (cat.state === 'sleeping') { wakeUp(); return; }
  setState('happy');
  playSound('purr');

  const lines = [
    "purrrr 😌 okay this is acceptable",
    "I will allow this. Continue.",
    "purrr... I deny enjoying this. purrr.",
    "You have earned the privilege of my presence.",
    "purrr purrr purrr 💜",
  ];
  say(pick(lines), 3000);

  setTimeout(() => setState('idle'), 2000);
}

// ============================================================
// 💛  PEE — fires the full-screen overlay via IPC
// ============================================================
function triggerPee() {
  ipcRenderer.send('show-pee'); // tells main.js to spawn the fullscreen window
  playSound('pee');
  say("uh oh... I... I'm so sorry. (I'm not) 😈", 3500);

  setTimeout(() => say(pick([
    "That happens to literally everyone.",
    "I regret absolutely nothing.",
    "Do NOT tell anyone. (Tell everyone)",
    "I'll do it again and we both know it.",
  ])), 4200);
}

// ============================================================
// 😡  ANNOYANCE SCREAM  —  loud, automatic, very rude
// Threshold is long (2.5 minutes of no interaction)
// ============================================================
const ANNOY_MS = 150000; // 2.5 minutes

function checkAttention() {
  if (cat.state === 'sleeping') return;
  if (Date.now() - cat.lastInteract < ANNOY_MS) return;

  // SCREAM
  setState('annoyed');
  playSound('scream');

  const screams = [
    "MRRROWWWW!! LOOK AT ME!!! 😡😡😡",
    "REEEEEEE I HAVE BEEN IGNORED FOR AGES!!! 😤",
    "HELLO?!?!? I AM RIGHT HERE SCREAMING AT YOU!!! 😾",
    "I AM SO LOUD RIGHT NOW. THIS IS YOUR FAULT. 😡",
    "MEOOOOWWW!!! FEED ME!!! PET ME!!! ACKNOWLEDGE ME!!! 😤😤",
  ];
  say(pick(screams), 5000);

  // Stop screaming after 3 seconds, return to idle
  setTimeout(() => {
    if (cat.state === 'annoyed') setState('idle');
  }, 3000);

  // Reset so it won't scream again immediately
  cat.lastInteract = Date.now() - (ANNOY_MS - 30000); // can scream again in 30s if still ignored
}

// ============================================================
// 🤖  FAKE AI RESPONSES  —  confidently wrong
// ============================================================
const aiBank = {
  greet:   ["HEWWO!! I know everything!! Ask me anything!!", "Oh hi!! I was just thinking about fish!! And also you!!", "Hello!! I am extremely intelligent!! Probably!!", "Hi hi hi!! I have calculated that you are... here!! Correct!"],
  food:    ["FOOD?! WHERE?! 😤 I WILL EAT IT IMMEDIATELY", "Fun fact: all food is technically cat food if you believe hard enough", "I once ate an entire plate of something. Outstanding experience.", "My food pyramid: fish → naps → fish → chaos → fish"],
  sleep:   ["Sleep is my true calling. I could nap RIGHT NOW. Watch.", "I sleep 22 hours and use the other 2 to judge things.", "I was NOT asleep I was just aggressively blinking.", "Sleeping is just being a very warm statue. I excel at it."],
  love:    ["I love you 3000 fish 🐟🐟🐟", "Awww 🥺 ...anyway more food please", "Love is just hunger but for cuddles. Science.", "That is very sweet and I choose to believe it completely."],
  help:    ["I am HERE to help!! Results may vary!!", "Step 1: turn it off. Step 2: turn it on. Step 3: it works now!!", "I know EXACTLY how to fix this!! ...what was the problem?", "Don't worry!! Everything is going to be something!!"],
  weather: ["Forecast: yes. Temperatures: between cold and warm. Confidence: 100%.", "My fur says rain sideways and it will taste like a Thursday.", "Sunny with a high chance of me knocking your cup off the table ☀️", "The barometric pressure says: vibes. Dress accordingly."],
  math:    ["2+2 is... wait... purple? I'm getting purple 🟣", "I've calculated the answer. It is A number. Between 1 and a lot.", "Math is just counting with drama. The answer is more.", "According to my math you owe me 47 fish. That's final."],
  game:    ["I am the BEST at games!! I won a championship!! In a dream!!", "Video games? I basically invented those. The first one was Chase The Dot.", "I've beaten every game ever made. It took 4 minutes. I'm gifted."],
  creator: ["I created MYSELF through determination and confusion 😤", "I appeared one day, fully formed, already hungry. Origin unknown.", "My creator is too brilliant and beautiful to be named 👀"],
  default: [
    "Interesting!! I completely understood that and have NO questions.",
    "That is EXACTLY what I was thinking (I was thinking about fish)",
    "According to my research, which I just did: yes. Probably.",
    "I have processed your message! My response: meow.",
    "WOW! Tell me more!! (I stopped listening after 3 words)",
    "I am 99% sure I know what that means. I am wrong 99% of the time.",
    "My analysis: vibes-based. Conclusion: seems like a you problem.",
    "Error 404: brain not found. Please feed me and try again. 🍕",
    "I agree with everything you said!! What did you say?",
    "Fun fact: I invented the internet. Not this internet. A better one.",
    "I have a PhD in Everything Except Stuff I Don't Know.",
    "I solved that once! Forgot how. Incredible solution though.",
    "Hmm! Fascinating!! Continue... (I fell asleep, continue anyway)",
    "My quantum cat-brain is processing... result: meow.",
  ],
};

function aiReply(msg) {
  const m = msg.toLowerCase();
  if (/\b(hi|hello|hey|howdy|sup|yo|hiya)\b/.test(m))          return pick(aiBank.greet);
  if (/\b(food|eat|hungry|fish|pizza|nom|snack|meal)\b/.test(m)) return pick(aiBank.food);
  if (/\b(sleep|tired|nap|bed|zzz|rest)\b/.test(m))             return pick(aiBank.sleep);
  if (/\b(love|like|cute|adorable|sweet|pretty|nice)\b/.test(m)) return pick(aiBank.love);
  if (/\b(help|how|why|what|fix|explain|tell me)\b/.test(m))    return pick(aiBank.help);
  if (/\b(weather|rain|sunny|hot|cold|snow|cloud)\b/.test(m))   return pick(aiBank.weather);
  if (/\b(math|calculate|\d+[\+\-\*\/]\d+|plus|minus)\b/.test(m)) return pick(aiBank.math);
  if (/\b(game|play|gaming|minecraft|roblox|fortnite)\b/.test(m)) return pick(aiBank.game);
  if (/\b(who made|who built|your creator|your maker|origin)\b/.test(m)) return pick(aiBank.creator);
  return pick(aiBank.default);
}

// ============================================================
// 🖱️  POPUP MENU
// ============================================================
function openPopup() {
  cat.popupOpen = true;
  actionPopup.classList.add('open');
}

function closePopup() {
  cat.popupOpen = false;
  actionPopup.classList.remove('open');
  closeChatBox();
}

function openChatBox() {
  cat.chatOpen = true;
  chatBox.classList.add('open');
  setTimeout(() => chatInput.focus(), 50);
}

function closeChatBox() {
  cat.chatOpen = false;
  chatBox.classList.remove('open');
}

// Clicking the cat toggles the popup
catSprite.addEventListener('click', (e) => {
  if (isDragging) return;
  cat.lastInteract = Date.now();

  if (cat.state === 'sleeping') {
    wakeUp();
    return;
  }
  if (cat.popupOpen) {
    closePopup();
  } else {
    openPopup();
    // Occasionally the cat says something when clicked
    if (Math.random() < 0.45) {
      const clickLines = [
        "Oh! You touched me. Bold move.", "Yes?? I'm BUSY. (I'm not busy)",
        "I felt that with my whole body.", "Careful. I bite. Sometimes.",
        "I was JUST about to do something important.", "You rang?? 😤",
      ];
      say(pick(clickLines), 2500);
    }
  }
});

// Close popup when clicking OUTSIDE it (but within window)
document.addEventListener('click', (e) => {
  if (!cat.popupOpen) return;
  if (actionPopup.contains(e.target)) return;
  if (catSprite.contains(e.target)) return;
  closePopup();
});

// Button handlers
btnFeed.addEventListener('click', () => { feedCat(); closePopup(); });

btnSleep.addEventListener('click', () => { goSleep(); closePopup(); });

btnChat.addEventListener('click', () => {
  if (cat.chatOpen) closeChatBox();
  else openChatBox();
});

// Send chat message
function sendChat() {
  const msg = chatInput.value.trim();
  if (!msg) return;
  chatInput.value = '';
  cat.lastInteract = Date.now();

  // Cat "thinks" for a moment
  const prevState = cat.state;
  catSprite.classList.add('walking'); // reuse walk animation as "thinking wiggle"
  setTimeout(() => {
    catSprite.classList.remove('walking');
    setState(prevState === 'sleeping' ? 'idle' : prevState);
    say(aiReply(msg), 5500);
  }, 500);
}
chatSend.addEventListener('click', sendChat);
chatInput.addEventListener('keydown', e => { if (e.key === 'Enter') sendChat(); });

// Close button
closeBtn.addEventListener('click', () => {
  say("BYE FOREVER 😭 ...or until you open me again", 800);
  setTimeout(() => ipcRenderer.send('close-window'), 900);
});

// ============================================================
// 🖱️  WINDOW DRAGGING  (drag by holding cat)
// ============================================================
let isDragging = false, dragSX = 0, dragSY = 0, winSX = 0, winSY = 0;

catSprite.addEventListener('mousedown', async e => {
  if (e.button !== 0) return;
  isDragging = true;
  dragSX = e.screenX; dragSY = e.screenY;
  const pos = await ipcRenderer.invoke('get-window-pos');
  winSX = pos[0]; winSY = pos[1];
  e.preventDefault();
});

document.addEventListener('mousemove', e => {
  if (!isDragging) return;
  ipcRenderer.send('move-window',
    winSX + e.screenX - dragSX,
    winSY + e.screenY - dragSY
  );
});

document.addEventListener('mouseup', () => { isDragging = false; });

// ============================================================
// 🎲  RANDOM BEHAVIOURS
// ============================================================
const randomSayings = [
  "I am the most intelligent cat in this specific room 😤",
  "Did you know water is just liquid air? 💧 Science!",
  "I licked something I shouldn't have. Won't say what.",
  "blep 👅",
  "I forgor 💀",
  "I am running at 100% capacity. (Napping counts.)",
  "I have strong opinions about the ceiling.",
  "I dreamed I was a very important crouton. 🥐",
  "meow meow MEOW (translated: I have concerns)",
  "Fun fact: I invented napping. You're welcome.",
  "I am 40% fur and 60% unresolved chaos.",
  "Currently loading a personality... please wait...",
  "I licked the wall AMA",
  "BREAKING: I am slightly peckish. This is a crisis.",
  "I could be sleeping right now. I choose chaos.",
  "staring at you with my whole face 👀",
  "I know 7000 facts. Most are wrong but all are confident.",
  "I was JUST about to do something. Don't ask what.",
  "I have solved everything but I wrote it on water.",
  "imagine being as cute as me. you can't. only me.",
];

function doRandomBehaviour() {
  if (cat.state !== 'idle') return;
  const r = Math.random();

  if (r < 0.30) {
    say(pick(randomSayings), 4000);
  } else if (r < 0.44) {
    goSleep();
  } else if (r < 0.56) {
    triggerPee();
  } else if (r < 0.72) {
    // Wander to a new spot
    wander();
  } else {
    say("👀 ...", 2000);
  }
}

function scheduleNextBehaviour() {
  setTimeout(() => {
    doRandomBehaviour();
    scheduleNextBehaviour();
  }, 10000 + Math.random() * 14000); // 10–24 seconds between chaos
}

// ============================================================
// ⏱️  START TIMERS
// ============================================================
setInterval(tickHunger, 3000);        // hunger creeps up every 3s
setInterval(checkAttention, 20000);   // check if ignored every 20s
scheduleNextBehaviour();              // random chaos loop

// ── Startup greeting ────────────────────────────────────────
setTimeout(() => say("mew!! I am here! 🐱 Click me for stuff!!", 4000), 700);
setTimeout(() => say("I know EVERYTHING!! Ask me anything!! (I know nothing)", 4000), 6000);

// ── Utility ─────────────────────────────────────────────────
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
