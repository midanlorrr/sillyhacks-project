// ============================================================
// MAIN.JS - Creates the pet window + handles fullscreen pee
// ============================================================
const { app, BrowserWindow, ipcMain, screen } = require('electron');

let win;
let peeWin = null;

function createWindow() {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;

  win = new BrowserWindow({
    width: 270,
    height: 300,
    x: width - 285,
    y: height - 315,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    resizable: false,
    skipTaskbar: false,
    hasShadow: false,
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    }
  });

  win.loadFile('index.html');
  // Uncomment the next line to open DevTools for debugging:
  // win.webContents.openDevTools({ mode: 'detach' });
}

// Move the pet window to any x,y on screen
ipcMain.on('move-window', (event, x, y) => {
  if (win) win.setPosition(Math.round(x), Math.round(y));
});

ipcMain.handle('get-window-pos', () => win ? win.getPosition() : [0, 0]);

ipcMain.handle('get-screen-size', () => {
  const { width, height } = screen.getPrimaryDisplay().workAreaSize;
  return { width, height };
});

// ── THE PEE OVERLAY ──────────────────────────────────────────
// Creates a SECOND window that covers the entire screen with yellow
ipcMain.on('show-pee', () => {
  if (peeWin) return;

  const { width, height } = screen.getPrimaryDisplay().workAreaSize;

  peeWin = new BrowserWindow({
    width, height, x: 0, y: 0,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    focusable: false,   // user can't accidentally interact with it
    skipTaskbar: true,
    hasShadow: false,
    webPreferences: { nodeIntegration: false, contextIsolation: true }
  });

  peeWin.setIgnoreMouseEvents(true); // Clicks pass straight through
  peeWin.loadFile('pee-overlay.html');

  setTimeout(() => {
    if (peeWin) { peeWin.close(); peeWin = null; }
  }, 4200);
});

ipcMain.on('close-window', () => {
  if (peeWin) { peeWin.close(); peeWin = null; }
  if (win) win.close();
});

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
